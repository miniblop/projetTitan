
<html>
		<head>
			<!--[if lt IE 9]>
			<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
			<![endif]-->
			<!--[if lt IE 9]>
			<script src="html5.js"></script>
			<![endif]-->
			<meta charset = 'utf-8'>
			<link rel ="stylesheet" href = "style_screen.css" media ='screen'>	
		</head>
	<body>
	<header>
	
		<ul id="header">
			<li><a href="http://facebook.com/zebeat"><img src="images/facebook.png" alt= "facebook"></a></li>
			<li><a href="http://www.youtube.com/channel/UCDPIFOp_JUBXt1TPcXZKhFQ"><img src="images/youtube.png" alt= "youtube"></a></li>
		</ul>
	
	</header>
	<nav>
		<ul id="nav">
			<li><a href = 'index.php'>HOME</a></li>
			<li><a href = 'contact.php'>CONTACT</a></li>  
		</ul>  	
	</nav>
</html>
	