
<html>
	<body>
	<footer>
		<div id="footer">
			Mentions légales :
			<br>
			<br>
			® Crabe TV
			<br>
			Website by Rémi Defonte
		</div>
		<div>
			Nos partenaires :
			<br>
			<br>
			Votre non ici? 
			<br>
			<a href = 'contact.php'>Contactez-nous</a>
		</div>
		<div>
			Nous soutenir :
			<br>
			<br>
			<a href = 'don.php'>Faire un don</a>
			<br>
			Parlez en autour de vous
		</div>
		
	</footer>
	</body>
</html>